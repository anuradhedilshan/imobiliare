import LoggerView from './LoggerView';

export default LoggerView;
