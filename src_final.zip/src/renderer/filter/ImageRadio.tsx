/* eslint-disable camelcase */
/* eslint-disable react/jsx-props-no-spreading */
import { Radio, RadioProps } from '@mui/material';

export default function CustomRadio(props: RadioProps) {
  return <Radio {...props} />;
}
